package com.learnkafka.entity;

public enum LibraryEventType {
    NEW,
    UPDATE
}
